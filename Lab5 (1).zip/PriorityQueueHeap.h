#include "PriorityQueueADT.h"

class PriorityQueueHeap : public PriorityQueueADT{

private:
	vector<int> _arr;


public:
	PriorityQueueHeap();
	~PriorityQueueHeap();
	bool empty();
	int size();
	int top();
	void push(int);
	void pop();
};
