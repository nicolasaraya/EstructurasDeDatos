#include "PriorityQueueADT.h"

class PriorityQueueUnsorted : public PriorityQueueADT{

private:
	vector<int> _arr;


public:
	PriorityQueueUnsorted();
	~PriorityQueueUnsorted();
	bool empty();
	int size();
	int top();
	void push(int);
	void pop();
};
