#include <bits/stdc++.h>
#include "PriorityQueueHeap.h"
#include "PriorityQueueUnsorted.h"

using namespace std;

void HeapSort(vector<int> &vec){
}

void SelectionSort(vector<int> &vec){
}

int main(){
	PriorityQueueADT *pqh = new PriorityQueueHeap();
	PriorityQueueADT *pqu = new PriorityQueueUnsorted();

	return 0;
}