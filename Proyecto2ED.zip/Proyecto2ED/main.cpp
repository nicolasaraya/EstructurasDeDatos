#include "Repairv1.h"
#include "Repairv2.h"
#include <time.h>

using namespace std;

int main(){
	srand(time(NULL));
	DList *s = new DList();
	DList *s1 = new DList();
	
	int c; 
	while(cin>>c){
		s->insertEnd(c);
		s1->insertEnd(c);
	}
	

	clock_t start = clock(); 
	double time;
	Repairv1* r = new Repairv1(s);
	cout<<"Solucion 1: ";
	r->cambiar();
	time = double(clock()-start)/CLOCKS_PER_SEC;
	printf("%.6f\n", time);

	cout<<endl;	
	start=clock();
	Repairv2* r2 = new Repairv2(s1);
	cout<<"Solucion 2: ";
	r2->cambiar();
	time = double(clock()-start)/CLOCKS_PER_SEC;
	printf("%.6f\n", time);

	r->prints();
	r2->prints();
	
	return 0;
}