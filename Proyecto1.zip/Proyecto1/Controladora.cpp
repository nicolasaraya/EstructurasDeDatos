#include "Controladora.h"
#include <vector>
#include <iostream>
#include <time.h>
using namespace std;

Controladora::Controladora(string dic, string pref, string res, int k){
    anadirDiccionario(dic);
    anadirPrefijos(pref);
    if( k>listD.size() ) k = listD.size(); //para que solo hayan los mismos resultados del diccionario 
    
    
    clock_t start = clock();
    p = new Predictor(listD,listFrec, k);
    double time = (double)(clock()-start)/CLOCKS_PER_SEC;
    printf("%.10f\n", time);
    vector<string> resultados = p->SolucionPrediccion(listP);
    crearResultados(res, resultados);
    resultados.clear();
}

Controladora::~Controladora(){
    listD.clear();
    listFrec.clear();
    listP.clear();
    delete p;   
}
void Controladora::anadirDiccionario(string dic){
    int a = 0;
    string line;
    diccionario.open(dic);
    if(diccionario.is_open()){
        while(!diccionario.eof()){
            diccionario >> line;
            if(line.find("%") == -1){
                a++;
                if(a%2==0){ 
                    listFrec.push_back(line);
                    continue;
                }
                listD.push_back(line);             
            }     
        }
    }
    else{
        cout << "No existe el archivo!" << endl;
    }
   	diccionario.close();      
    line.clear();
    
}
void Controladora::anadirPrefijos(string pref){
    string line;
    prefijos.open(pref);
    if(prefijos.is_open()){
        while(!prefijos.eof()){
            prefijos >> line;
            if(line.find("%") == -1) listP.push_back(line);    
        }
    }
    else{
        cout << "No existe el archivo!" << endl;
    }
    prefijos.close();      
    line.clear();
}
void Controladora::crearResultados(string res, vector<string> r){ 
    resultados.open(res);
    for(int i = 0; i<r.size(); i++){ //como el vector ya viene ordenado del metodo SolucionPrediccion solo hay que añadir string a string al archivo resultados.txt
        resultados<<r[i];
    }
    resultados.close();
}