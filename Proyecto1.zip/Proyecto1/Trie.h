#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;

struct Nodo{
    bool fin;
    int frecuencia;
    Nodo* siguiente[27];
};



class Trie{
    private:
        Nodo* root;
        vector<pair <int,string> > Relleno(Nodo* n, vector<pair <int,string> > respuestas, string s, char e);
        void BorrarRamas(Nodo* n);
    public:
        Trie();
        ~Trie();
        void insert(string s,int p);
        vector<pair <int,string> > Seleccion(string s, int k, char e);
        void setFrec(string s);
};