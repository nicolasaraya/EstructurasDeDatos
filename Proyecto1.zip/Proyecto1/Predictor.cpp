#include <vector>
#include "Predictor.h"
using namespace std;

Predictor::Predictor(vector<string> dic, vector<string> f, int k){
	t = new Trie();
	this->k=k;
	for (int i = 0; i < f.size(); ++i) frecuencias.push_back(stoi(f[i])); //crea un vector<int> con los valores de frecuencia
	for (int i = 0; i < dic.size(); ++i) t->insert(dic[i], frecuencias[i]); //anade cada palabra al trie
}

Predictor::~Predictor(){
	delete t;   
	frecuencias.clear();
}

vector<string> Predictor::BusquedaPrediccion (string pre, vector<string> res, int k, char c){
	vector<pair <int,string> > aux = t->Seleccion(pre, k, c); //hace la seleccion en el trie.
	vector<string> respuestas=res;
	for(int i=0; i<aux.size(); i++){   //añade las palabras que recibe de Seleccion a un vector
    	respuestas.push_back(aux[i].second);
		respuestas.push_back(" ");
		t->setFrec(aux[i].second);     //incrementa la frecuencia de la palabra en el trie
	}
	if(aux.size()<k){                   //si se obtuvieron menos palabras que "k" se vuelve a llamar a la funcion sin la ultima letra del prefijo
		char s = pre[pre.size()-1];
		pre.pop_back();
		if(pre.size()==0) return BusquedaPrediccion("", respuestas, k-aux.size(), s); //cuando ya el prefijo no tiene letras, se buscan las mas frecuentes del dicionario omitiendo las que empiezan con la primera letra del prefijo 
		respuestas = BusquedaPrediccion(pre, respuestas, k-aux.size(), s); 
	}
	return respuestas;
}

vector<string> Predictor::SolucionPrediccion (vector<string> p){
	vector<string> resultados;
	for(int i = 0; i<p.size(); i++){ //crea la estructura que tendra el archivo resultados.txt
		resultados.push_back(p[i]);
		resultados.push_back(": ");
		resultados = BusquedaPrediccion(p[i], resultados, k, 0); 
		resultados.push_back("\n");
	}
	return resultados;
}