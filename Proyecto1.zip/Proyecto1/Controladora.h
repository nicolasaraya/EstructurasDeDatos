#include "Predictor.h"
#include <vector>
#include <fstream>

using namespace std;
class Controladora {
	private:
		Predictor *p;
		vector<string> listD, listFrec, listP;
		ifstream diccionario, prefijos;
		ofstream resultados;
		void anadirDiccionario(string s);
		void anadirPrefijos(string p);
		void crearResultados(string res, vector<string> r);
    	
	public:
		Controladora(string dic, string pref, string res, int k);
		~Controladora();
};