#include <iostream>
#include "Controladora.h"
using namespace std;

int main(int argc, char const *argv[]){
    Controladora *c = new Controladora(argv[1], argv[2], argv[3], atoi(argv[4]));
    delete c;
    return 0;
}
