#include <iostream>
#include <vector>
#include<algorithm>
#include "Trie.h"

using namespace std;  

bool sortFrec(const pair<int,string> &a, const pair<int,string> &b){  
    if(a.first == b.first) return(a.second < b.second);
    
    return (a.first > b.first); 
} // funcion externa a la clase 

Trie::Trie(){
    root = new Nodo();
    root->fin = false;
}

Trie::~Trie(){
    if(root!=NULL) BorrarRamas (root); // se elimina la root igual
    delete root;
}

void Trie::BorrarRamas(Nodo* n){ //metodo recursivo para eliminar cada nodo
    for(int i = 0; i<27; i++){
        if(n->siguiente[i]!=NULL){
            BorrarRamas(n->siguiente[i]);
            delete n->siguiente[i];
            n->siguiente[i] = NULL;
        }  
    }
}

void Trie::insert(string s, int p){     //inserta la string letra a letra.
    Nodo* aux=root;
    for(int i=0; i<s.size(); i++){
        if(aux->siguiente[s[i]-97]==NULL){ //si el nodo asociado a la letra no existe lo crea
            aux->siguiente[s[i]-97]=new Nodo();
        }
        aux = aux->siguiente[s[i]-97];      //pasa al siguiente nodo
    }
    aux->fin = true;
    aux->frecuencia = p;

}


void Trie::setFrec(string s){          //incrementa la frecuencia de la palabra
    Nodo* aux=root;
    for(int i=0; i<s.length(); i++){
        aux=aux->siguiente[s[i]-97];
    }
    aux->frecuencia++;
}


vector<pair <int,string> > Trie::Seleccion(string s, int k, char e){  //entrega el vector con las "k" soluciones asociadas al prefijo
    vector<pair <int,string> >respuestas, solucion;
    if (root == NULL) return respuestas; //si no hay palabras en diccionario
    Nodo* aux=root;
    for(int i=0; i<s.length(); i++){  //encuentra el nodo asociado a la ultima letra del prefijo
        aux=aux->siguiente[s[i]-97];
        if(aux==NULL) return respuestas;
    }
    respuestas = Relleno(aux, respuestas, s, e);
    sort(respuestas.begin(),respuestas.end(), sortFrec); //ordena el vector en funcion a las condiciones dadas por la funcion sortFrec
    if(k>respuestas.size()) return respuestas; 
    else { //para no enviar mas soluciones que las que se piden, se devuelven las "k" primeras
        for(int i=0; i<k; i++){
            solucion.push_back(make_pair(respuestas[i].first,respuestas[i].second));
        }
    }
    return solucion;
}

vector<pair <int,string> >Trie::Relleno(Nodo* n, vector<pair <int,string> > respuestas, string st, char e){ //busca todas las palabras a partir del nodo recibido y exceptuando la rama del "char e"
    string init = st; //guarda el prefijo original
    for(int i=0; i<27; i++){
        if(n->siguiente[i]!=NULL && i!=e-97){
            respuestas = Relleno(n->siguiente[i], respuestas, st+=(i+97), 0); //accede a cada nodo recursivamente
            if(n->siguiente[i])st=init;               
        }       
    }
    if(n->fin==true){
        respuestas.push_back(make_pair(n->frecuencia,st)); //las anade cuando encuentra el fin de la palabra
        return respuestas;
    }
    return respuestas;
}