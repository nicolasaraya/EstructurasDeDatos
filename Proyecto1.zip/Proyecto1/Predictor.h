#include <vector>
#include <string>
#include "Trie.h"
using namespace std;

class Predictor {
	private:
		Trie *t;
		vector <int> frecuencias;
		int k;
		vector<string> BusquedaPrediccion(string pre, vector<string> res, int k, char c);
	public:
		Predictor(vector<string> dic,vector<string> f, int k);
		~Predictor();
		vector<string> SolucionPrediccion(vector<string> p);
};