#include <iostream>
#include <fstream>
#include <vector>
#include <time.h>

using namespace std; 

bool existe(int n, vector<int> array){
    bool ans = false;
    for(int i = 0; i<array.size(); i++){
        if(array[i]==n){
            ans=true;
            return ans;
        }
    }
    return ans;
}



int main(int argc, char const *argv[]){
    int cantidad;
    cin>>cantidad;
    ifstream dic;
    ofstream dicSalida;
    vector<string> diccionario;
    string line;
    dic.open(argv[1]);
    if(dic.is_open()){
        while(!dic.eof()){
            dic >> line;
            if(line.find("%") == -1){
                diccionario.push_back(line);
            }
        }
    }
    else{
        cout << "No existe el archivo!" << endl;
    }
    dic.close();      
    line.clear();
    dicSalida.open("diccionario.txt");
    srand(time(NULL));
    vector<int> indices;
    for(int i = 0; i<cantidad; i++){
        int x = rand()%diccionario.size();
        while(existe(x, indices)){
            x = rand()%diccionario.size();
        }
        indices.push_back(x);
        
    }
    int dif = (diccionario.size() / cantidad );
    for(int i = 0; i<cantidad; i++){ 
        char c=32;
        dicSalida<<diccionario[indices[i]]<<c<<rand()%1000+1;
        if(i<cantidad-1){
            dicSalida<<"\n";
        }
    }
    dicSalida.close();

    return 0;
}
